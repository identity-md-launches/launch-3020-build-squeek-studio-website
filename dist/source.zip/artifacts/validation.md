# Squeek Studio validation

The implementation and the Chromium checks below are complete. These are worker observations, not an independent certification; the assignment's verifier checks paths and bytes. Safari, physical-wallet approval, and physical-device sharing remain unverified as detailed below.

| Area | Final observation |
| --- | --- |
| Brief coverage | 20 implementation areas met; 0 known missing implementation areas; 0 fake live features |
| Production build | Passed, `npm run build` |
| TypeScript | Passed, `npm run typecheck` |
| Pure-function tests | 8 passed, 0 failed, `npm test` |
| Production interactions | 21 passed, 0 failed, `npm run check` |
| Wallet/provider and image checks | 11 passed, including all held/deposited results, five-member team, exact signing message/rejection, QR decoding and sticker alpha |
| Canvas decoration cases | 11 passed, including all frame tiers, ribbon thresholds/colors, rare foil boundary, ACTIVE-only glow and a combined Vietnamese ID render |
| Keyboard/fallback checks | 6 passed, including main-thread PNG export, real clipboard item with granted permission, full 100-item gallery and 360px Vietnamese first screen |
| Automated accessibility | 7 surfaces with 0 WCAG-tagged axe violations; incomplete/manual checks disclosed below |
| taste@1 | 16/16 passed on the final runtime export |
| First screen at 390 | Product, real art and preview action visible; screenshot inspected |
| Share metadata | Title, favicon, description, og:title and local 1200×630 PNG og:image present |
| Packaging | Passed integrity and 8 MiB gate; relative assets, public/export parity, snapshot and full source archive verified |

Detailed machine-readable observations are in [validation-results.json](validation-results.json). Final captures: [390px landing](home-390.jpg), [1440px landing](home-1440.jpg), [1440px studio](studio-1440.jpg). Test downloads and fixture images are disposable `test/scratch/` evidence, not shipped artwork or live-data claims.

## Brief coverage

| Requirement area | Status and implementation |
| --- | --- |
| Vite + TypeScript + viem; static relative/hash export | Met: source, lockfile, `dist/index.html`, hashed local assets, `base: './'`; served and tested under `/preview/`. |
| Landing, real examples and ID preview | Met: six real tokenURI-derived Squeeks, token-ID validation, no-wallet studio entry and Preview export tag. |
| EIP-1193 wallets and complete holder list | Met: EIP-6963 names/icons, legacy fallback, current owner/depositor reads, every API page, and all historically deposited IDs to include operator deposits. |
| Optional holder verification | Met: exact personal_sign message, viem signer recovery and signature fingerprint; ownership checked before signing and export. Rejection and account change tested. A real holder signature was not obtained. |
| Six exact formats | Met: 1000×1000, 1500×500, 1170×2532, 2560×1440, six 512×512 PNGs, 1200×750. Downloaded PNG headers checked. |
| Six transparent poses | Met: original glyph-grid reposing/recoloring; six distinct PNGs in ZIP; every file's alpha checked. |
| Full ID card | Met: all 11 traits and percentages, rarest highlight, level, custody, age, short holder and QR. QR decoded to the site's own hash route. |
| Eight original templates | Met: The original, In orbit, Dot matrix, Paper cut, After hours, Postcard, Soft bloom, Signal. Palette tints and Background patterns come from the Squeek. |
| Real-data frames/ribbons/foil/wheel | Met: pure threshold rules and browser pixel checks; unknown data hides qualifying decorations. Wheel is reread at generation and timestamped. |
| Duo/team banner | Met: up to five owned Squeeks, sixth disabled, each member rechecked, real 1500×500 download. |
| Sharing | Met: blob download, promised PNG clipboard item, native-share File objects, manual X intent link. No files uploaded and no post sent. |
| Public Squeek page | Met: canonical art, semantic trait table, rarity block, level, current custody, full holder disclosure and Make art action. |
| Latest-100 gallery and filter | Met: descending Transfer events with burns excluded; actual full gallery loaded to 100, trait/value filters and clear action tested. |
| Attribute snapshot | Met: 9,096 records, block 12073886, 2026-11-06 03:23:48 UTC, 903 burns, 11 columns, no images. Population equals on-chain totalSupply at the fixed block. |
| Read-only data resilience | Met: supplied RPC order/10s timeouts, Multicall3, API pagination, IndexedDB, current-deposit age and explicit unknown/cached states. RPC/API-blocked preview tested. |
| EN/VI and themes | Met: central i18n file, switch/document lang, both themes; Vietnamese first-screen action checked at 360px. |
| Accessibility and responsiveness | Met for checked Chromium scope: native controls, named modal, focus return, visible rings, 44px targets, 320px reflow and reduced motion. Manual/native limits remain. |
| About and attribution | Met: methods, privacy qualification, testnet disclaimer, creator, Genesis referral and local complete-source download. |
| Safety and network boundary | Met: no transaction/approval/transfer/key-entry flow; only allowed read endpoints plus local assets. CSP and disabled CCIP reads; no analytics/trackers. |
| Documentation and delivery | Met: README, DESIGN.md, license notices, complete source/archive and production export. Dependency/cache paths excluded at every nesting level. |

The one visual idea is a warm paper studio framing the Squeek's own dot-grid character. The implementation prioritizes the preview and creation action over promotional content.

## Better Interface: six-domain coverage

| Domain | Coverage and evidence | Limits |
| --- | --- | --- |
| Accessibility | Checked: source semantics, native labels/controls, named dialog, modal Escape/focus return, actual Tab/type/Enter preview and download, visible 3px focus ring, reduced motion, axe on Home/Studio/Banner guide/Studio dark/Public/About/Dialog. | No native screen-reader session or physical-device input. Axe is not a full accessibility certification. |
| Layout | Checked: actual production export at 320, 360, 390, 768 and 1440px; no horizontal overflow in tested views; native trait table, editor stacking, full 100-item gallery, EN/VI content growth. taste also found no text overlap or clipped text on its entry-page views. | Native browser 200% zoom was not performed. Not every viewport/state combination was exhaustively sampled. |
| Writing | Checked: short hero and plain product line, instructions next to the ID field, actual loading/empty/cached/failure/retry copy, clear wallet refusal and share/clipboard support responses; central translations. Final first-screen prose: 17 words at 390 (bar 60). | On-chain trait values/merge-state strings retain their source spelling. |
| Typography | Checked: local system sans, 400/600 weights, six-token scale, bounded prose, 16px mobile fields, wrapping/full address disclosure, tabular numbers. taste measured five sizes including one-offs at 390 and 1440. | Platform font rasterization and export text vary by OS. No external font was loaded. |
| Colors | Checked: both theme blocks, actual resolved text/background pairs through taste and axe. Studio caption's failing 4.41:1 pair was fixed and rechecked; 0 final axe violations in light and dark studio. Editable export backgrounds choose contrasting text. | taste leaves 3 art-backed text boxes unmeasured; axe landing has 2 incomplete checks. Arbitrary artwork/palette combinations were visually inspected, not universally contrast-certified. |
| UI | Checked: selection, hover/active/focus source rules, native pending/disabled controls, no-provider sheet, invalid ID, failed signature, unavailable token, cached preview, successful downloads, clipboard and share fallback. Native dialog and main-thread renderer fallback exercised. | WebKit, real extension prompts and native mobile share sheets could not be observed. |

## Findings, corrections and rechecks

1. **High — studio caption contrast.** `src/style.css:2263`, `.export-panel .hint`. Axe measured `#61675b` on `#dce3cc` at **4.41:1**, below 4.5:1. Changed the caption to the existing `--sage-ink` role. Rechecked both light and dark studio: zero axe violations.
2. **High — comfortable control targets.** `src/style.css:2266`, native range; `src/style.css:2269`, navigation/footer targets. Increased actual interactive dimensions to at least 44px. Final taste report: **0 controls under 44px** on the 390px landing; source and keyboard checks cover the editor's native controls.
3. **Medium — repeated two-beat slogans.** `src/i18n.ts:27`, `realArt`; `src/i18n.ts:29`, `noGas`, and matching VI entries. The first probe counted nine two-beat fragments. Kept the four-word hero and replaced supporting slogans with direct facts. Final slogans/copy-budget checks pass; first-screen prose is 17 words.
4. **Medium — pale glyphs and custom background text.** `src/lib/render.ts:124`, `templateBackground`; `src/lib/render.ts:159`, `readableInk`. Pale on-chain colors were weak on light templates. Added a dark character field for light canvases and contrasting export ink for chosen backgrounds. Inspected the actual PNGs and the combined Vietnamese ID fixture; no numeric contrast claim is made for every artwork pixel.
5. **High — deposited ownership and provider failure.** `src/lib/data.ts:226`, `walletSqueeks`. An NFT in Staking belongs to its depositor; an operator deposit need not have the same Transfer sender. The final scan checks all historical deposited IDs and validates current custody. All-failed multicalls trigger cached/error recovery rather than overwriting a wallet with a false empty list. Held and deposited public data passed the provider simulation.
6. **High — snapshot gas and historical-state limits.** `scripts/snapshot.ts:112`, `existingAt`, and `--rebase`. Render-heavy multicalls exceeded provider gas caps; the initial historical state was later pruned. Batches split, failed URIs receive an existence check, and rebasing verifies every issued ID at a new fixed block while reusing only immutable traits. Final population is exactly **9,096**, matching fixed-block totalSupply; metadata records both immutable read blocks.
7. **Medium — combined badge collisions and ineffective controls.** `src/lib/render.ts:447` through the specialized badge positions; `src/App.tsx:1151`, `stickerControls`. Moved ID, banner, PFP and sticker seals/ribbons into separate areas; sticker size now affects the glyph grid. Hid template/background/name controls that do not apply to stickers. Combined badge/VI fixture and six-format downloads passed.
8. **Medium — table/modal semantics.** `src/App.tsx:459`, `Traits`; `src/App.tsx:1576`, `WalletDialog`. Replaced the generic trait grid with a native table and named the native dialog via its heading. Public page and modal pass axe; Escape returns focus to Connect wallet.
9. **Medium — clipboard gesture and worker cleanup.** `src/App.tsx:815`, `exportArt`; `src/lib/export.ts:15`, `disableWorker`. Clipboard access is requested in the click with a promised PNG, and worker jobs/timers are removed on completion or failure. A shared failure falls back to the same renderer. Real image/png clipboard write/read with granted permission and forced main-thread download both passed.
10. **Medium — stale/incomplete export facts.** `src/App.tsx:769`, `generate`. Every generation awaits fresh/cached facts as well as wheel status, including previews; owned seals get a further current custody check. Final exact-size download suite passed after this change.

**Low — guide visibility over pale art.** `src/style.css`, `.circle-guide` and `.avatar-guide > span`. The studio screenshot showed a faint white-only circle on pale artwork. Added a contrasting dual outline and a solid label backing; inspected the final guide and rechecked format interactions.

No known high-impact implementation findings remain within the checked scope. The following are explicit coverage limitations, not claimed passes.

## Commands and actual results

- `npm run typecheck`: exit 0.
- `npm test`: exit 0; 8 pure tests, covering held/deposited ownership, rarity and unseen values, frame/ribbon/foil boundaries, exact sizes/safe zones, SVG color extraction, current-deposit age and data-URI validation.
- `npm run build`: exit 0; production assets exported to `dist/` with relative URLs.
- `npm run check`: exit 0; 21 production interaction checks. The ordinary no-permission clipboard case produced a clear support message; a separate granted-permission run wrote/read a real PNG item.
- Worker wallet/image harness: exit 0; 11 checks. Test-only EIP-1193 prompts used real public contract/API reads; no real wallet account was controlled and no transaction was sent.
- Worker renderer harness: exit 0; 11 cases using explicitly synthetic threshold fixtures with real Squeek art. These fixture levels/days are not shipped as live metadata.
- Worker keyboard/fallback harness: exit 0; 6 checks, including full 100-record gallery, actual 1000×1000 fallback PNG, clipboard and 360px VI layout.
- Worker axe harness: exit 0 after the contrast correction; 7 surfaces, 0 violations, with the landing's incomplete checks retained in the results file.
- `node .imd/reads/skills/design-critic/scripts/taste.mjs --out test/scratch/taste-final`: exit 0 through the installed-Chromium adapter; **16/16**. No missing local assets, script errors, overflow, overlap, clipped text, unsupported type-size stack or reduced-motion failures. The pinned script itself was not edited.
- Snapshot: completed all issued IDs at fixed block 12073886 after rebase; 9,096 attribute rows, 903 confirmed burns, 11 traits, 1,339,029-byte attributes-only JSON. Missing snapshot behavior was also exercised before the file existed; the studio rendered with rarity hidden.
- Final capture: all 11 public-page rarity percentages and the displayed snapshot block were checked on the production export. Screenshot paths above correspond to that export.

The supplied browser tool failed before navigation because its configured Chrome distribution was absent. The worker used an existing headless Chromium binary with one browser at a time and bounded renderer processes; every check closed its browser/server in `finally`. The read-only RPC/API test bridge uses the exact named public endpoints through curl, not a fake registry or fixture backend.

## Remaining limitations

- WebKit failed to launch with **`liblcms2.so.2: cannot open shared object file`**. Safari remains unverified; no system library or machine configuration was changed.
- Real extension connection/approval and a real holder's signature were not performed. Signature rejection, exact message/address, ownership gates, and account/chain changes were tested with a controlled provider.
- Native mobile file sharing and wallet app deep links were not exercised on a physical phone. File-sharing wiring passed six real PNG `File` objects to a browser-only stub; no external upload occurred.
- No native screen-reader or native 200% browser zoom session. Reflow, keyboard, semantic scans and reduced-motion tests cover the stated narrower scope.
- Clipboard availability depends on secure context and browser permissions. Both the explicit support fallback and a granted-permission real PNG item were tested.
- X sharing was checked as an intent link, not posted. External navigation does not occur automatically.
- RPC/API availability and indexing lag remain external dependencies. Unknown data stays unknown. Offline verification blocked those providers while the static shell remained served; first-visit shell access without a network is not claimed.
- The guide probe covers the entry route. Its 3 art-backed text boxes and axe's 2 incomplete landing checks were not treated as measured passes. Editable artwork remains a visual/manual concern.

## Final packaging gate

`npm run source`, `npm run build`, and `npm run audit` produce and validate the final source download and production export. `scripts/audit-bundle.py` checks relative index assets, byte-for-byte public/dist parity, all snapshot rows, the 1200×630 share image, complete up-to-date source archive, absence of submodules/symlinks, and the **8,388,608-byte** contribution budget. Generated dependency/cache directories and disposable test evidence are excluded by the explicit ignore-path budget. **Result: passed.** The measured contribution is approximately 6.1 MiB, below the 8 MiB gate. The audit also checks every archived file against its current source and verifies every source module is included. Runtime asset hashes are checked against the tested export after the final documentation/source-archive rebuild.
